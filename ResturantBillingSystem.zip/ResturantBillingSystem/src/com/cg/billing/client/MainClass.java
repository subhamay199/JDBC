package com.cg.billing.client;
import java.util.List;
import java.util.Scanner;

import com.cg.billing.beans.Customer;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;
public class MainClass {
	public static void main(String[] args) throws CustomerDetailsNotFoundException{
		BillingServices services=new BillingServicesImpl();
		double netBill;
		Scanner sc=new Scanner(System.in);
		int customerId=services.acceptCustomerDetails("frank","castle","frank@mcu.com",9876,120,100,200);
		System.out.println("Customer Id:- "+customerId);
		int customerId2=services.acceptCustomerDetails("dinah","madani","dinal@mcu.com",9877,220,150,100);
		System.out.println("Customer Id:- "+customerId2);
		while(true) {
		System.out.println("---------------------");
		System.out.println("Enter your choice");
		System.out.println("1. get Customer details");
		System.out.println("2. get Total Bill");
		System.out.println("3. get all Customer details:");
		System.out.println("4. exit");
		int choice = sc.nextInt();
		switch(choice) {
		case 1:
//			System.out.println(services.getAllCustomerDetails());
			System.out.println("Enter the employee id you want to search: ");
			int num=sc.nextInt();
			try {
			System.out.println(services.getCustomerDetails(num));
			}
			catch(CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 2:
			System.out.println("Enter Customer Id to get Total Bill : ");
			int sal = sc.nextInt();
			System.out.println("------------");
			boolean a = services.getCustomerDetails(sal) != null;
			try {
				services.getCustomerDetails(sal);
						netBill=services.calculateTotalBillAmount(customerId);
						System.out.println("Total Bill for Customer "+ customerId+" is "+netBill);
			}
				catch(CustomerDetailsNotFoundException e) {
					e.printStackTrace();
			}
			break;
		case 3:
			List<Customer> a11=services.getAllCustomerDetails();
			for(Customer customer2: a11) {
				System.out.println(customer2);}
			break;
		case 4:
			System.exit(0);
		default:
			System.out.println("wrong choice");
		}
		}
	}
}