package com.cg.banking.services;
import java.util.List;
import java.util.Map;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
public class BankingServicesImpl implements BankingServices{
	private AccountDAO accountDao=new AccountDAOImpl();
	private TransactionDAO transactionDao=new TransactionDAOImpl();
	public BankingServicesImpl(AccountDAO mockAccountDao) {
		this.accountDao=mockAccountDao;
	}
	public BankingServicesImpl() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account=new Account(accountType,initBalance);
		account=accountDao.save(account);
		return account;
	}
	@Override
	public float depositAmount(int accountNumber, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNumber);
		if(account.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else
			account.setAccountBalance(account.getAccountBalance()+amount);
		transactionDao.save( accountNumber, new Transaction(amount,"Deposit"));
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(int accountNumber, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNumber);
		if(account.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else if(account.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException();
		else if(account.getAccountBalance()-amount<500)
			throw new InsufficientAmountException();
		else
			account.setAccountBalance(account.getAccountBalance()-amount);
		transactionDao.save((int) accountNumber, new Transaction(amount,"Withdraw"));
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(int accountNoTo, int accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerNoTo=getAccountDetails(accountNoTo);
		Account customerNoFrom=getAccountDetails(accountNoFrom);
		if(customerNoTo.getAccountStatus().equalsIgnoreCase("Blocked") || customerNoFrom.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else if(customerNoFrom.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException();
		else if(customerNoFrom.getAccountBalance()-transferAmount<500)
			throw new InsufficientAmountException();
		else {
			customerNoTo.setAccountBalance(customerNoTo.getAccountBalance()+transferAmount);
			transactionDao.save(customerNoTo.getAccountNo(), new Transaction(transferAmount,"Deposit"));
			customerNoFrom.setAccountBalance(customerNoFrom.getAccountBalance()-transferAmount);
			transactionDao.save(customerNoFrom.getAccountNo(), new Transaction(transferAmount,"Withdraw"));
		}
		return true;
	}
	@Override
	public Account getAccountDetails(int accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=accountDao.findOne(accountNo);
		if(account==null)
			throw new AccountNotFoundException();
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		return accountDao.findAll();
	}
	@Override
	public Map<Long,Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		return null;
	}
	@Override
	public String accountStatus(int accountNumber)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account=getAccountDetails(accountNumber);
		if(account.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else
			return "Active";
	}
}