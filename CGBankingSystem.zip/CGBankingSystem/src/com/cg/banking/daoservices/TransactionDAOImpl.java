package com.cg.banking.daoservices;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionDAO{

	@Override
	public Transaction save(int accountNumber, Transaction transaction) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Transaction findOne(int accountNumber, int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> findAll(int accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
