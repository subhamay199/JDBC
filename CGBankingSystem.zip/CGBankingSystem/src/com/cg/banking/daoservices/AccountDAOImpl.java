package com.cg.banking.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDBUtil;

import oracle.net.aso.a;
public class AccountDAOImpl implements AccountDAO {
	private static Connection con = BankingDBUtil.getDBConnection();
	@Override
	public Account save(Account account) {
			try {
			con.setAutoCommit(false);
			PreparedStatement pstmt1 = con.prepareStatement("insert into Account(accountNo, accountType, accountStatus, accountBalance) values(Account_ID_SEQ,?,?,?)");
			//pstmt1.setInt(1, associate.getAssociateId());
			pstmt1.setInt(1, account.getAccountNo());
			pstmt1.setString(2,account.getAccountType());
			pstmt1.setString(3, account.getAccountStatus());			
			pstmt1.setFloat(4, account.getAccountBalance());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2 = con.prepareStatement("select max(accountNo) from Account");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int accountNo=rs.getInt(1);

		//	PreparedStatement pstmt3 = con.prepareStatement("insert into Transaction(transactionId, amount, transactionType) values(?,?,?,?)");
		//	pstmt3.setInt(1, accountNo);
//			pstmt3.setFloat(2, account.getTransactions().get);
//			pstmt3.setInt(3, associate.getSalary().getEpf());
//			pstmt3.executeUpdate();

			account.setAccountNo(accountNo);
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean update(Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account findOne(int accountNo) {
		try {
			PreparedStatement pstmt1 = con.prepareStatement("select * from Account where accountNo = "+accountNo);
			
			ResultSet associateRs = pstmt1.executeQuery();
			if(associateRs.next()) {
				int accountNo1=(associateRs.getInt("accountNo"));
				int pinNumber=(associateRs.getInt("pinNumber"));
				String accountType = (associateRs.getString("accountType"));
				String accountStatus= (associateRs.getString("accountStatus"));
				float accountBalance=(associateRs.getFloat("accountBalance"));
				pstmt1.executeUpdate();
				
				Account account=new Account(accountNo1, pinNumber, accountType, accountStatus, accountBalance);
				return account;
			}
			return null;
		}
			catch(SQLException e) {
				e.printStackTrace();
			}
		return null;
	}

	@Override
	public List<Account> findAll() {
		ArrayList<Account> accounts=new ArrayList<Account>();
		try {
			PreparedStatement pstmt1 = con.prepareStatement("select * from Account ");
			
			ResultSet associateRs = pstmt1.executeQuery();
			if(associateRs.next()) {
				int accountNo1=(associateRs.getInt("accountNo"));
				int pinNumber=(associateRs.getInt("pinNumber"));
				String accountType = (associateRs.getString("accountType"));
				String accountStatus= (associateRs.getString("accountStatus"));
				float accountBalance=(associateRs.getFloat("accountBalance"));
				pstmt1.executeUpdate();
				
				Account account=new Account(accountNo1, pinNumber, accountType, accountStatus, accountBalance);
				
			}
			return null;
		}
			catch(SQLException e) {
				e.printStackTrace();
			}
		return accounts;
	}
	
}
