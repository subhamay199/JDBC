package com.cg.banking.exceptions;
public class InsufficientAmountException extends RuntimeException{
	public InsufficientAmountException(){
		System.out.println("Insufficient Amount in your account");
	}
}
