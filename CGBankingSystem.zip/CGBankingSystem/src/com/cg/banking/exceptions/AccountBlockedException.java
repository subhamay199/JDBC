package com.cg.banking.exceptions;
public class AccountBlockedException extends RuntimeException{
	public AccountBlockedException(){
		System.out.println("Your Account is blocked");
	}
}
