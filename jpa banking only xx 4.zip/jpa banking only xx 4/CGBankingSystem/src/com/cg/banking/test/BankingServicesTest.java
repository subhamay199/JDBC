package com.cg.banking.test;

import java.util.ArrayList;
import java.util.HashMap;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class BankingServicesTest {
	private static BankingServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new BankingServicesImpl();
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForInvalidAccountId() throws AccountNotFoundException, BankingServicesDownException {
		services.getAccountDetails(1000);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForValidAccountId() throws AccountNotFoundException, BankingServicesDownException {
		Account expectedAccount = new Account(101, 6554, "savings", "Active", 200, new HashMap<Integer, Transaction>(1) );
		Account actualAccount=services.getAccountDetails(101);
		Assert.assertEquals(expectedAccount, actualAccount);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsforInvalidAmount() throws AccountNotFoundException, BankingServicesDownException {
		services.getAccountDetails(12345);
	}
	@Test
	public void testGetAllAccountDetailsforInvalidAmount() throws AccountNotFoundException, BankingServicesDownException {
		Account account1=new Account(5001, 1234, "Savings", "Active", 5000,new HashMap<Integer, Transaction>(1));
		Account account2=new Account(5002, 2345, "Savings", "Blocked", 10000,new HashMap<Integer, Transaction>(1));
		ArrayList<Account> expectedAccountList=new ArrayList<Account>();
		expectedAccountList.add(account1);
		expectedAccountList.add(account2);
		ArrayList<Account> actualAccountList=(ArrayList<Account>)services.getAllAccountDetails();
		Assert.assertEquals(expectedAccountList, actualAccountList);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testAccountStatusForValidAccountNumber() throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		String expectedStatus="Active";
		String actualStatus=services.accountStatus(101);
		Assert.assertEquals(expectedStatus, actualStatus);
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}
}
