package com.cg.payroll.client;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class TestMain {

	public static void main(String[] args) {
		
				//PayrollDBUtil.getConnection();
		//System.out.println("Connected");
		PayrollServices services=new PayrollServicesImpl();
		int associateId1=services.acceptAssociateDetails("nilotpal", "majumdar", "kutan16@gmail.com", "IT", "Analyst", "dfg4gf", 20000, 12000, 1800, 1800, 3793, "sbi", "sbin00584");
		System.out.println(associateId1);
		int associateId2=services.acceptAssociateDetails("nilotpal", "majumdar", "kutan16@gmail.com", "IT", "Analyst", "dfg4gf", 20000, 12000, 1800, 1800, 3793, "sbi", "sbin00584");
		System.out.println(associateId2);
		//Associate associate = null;
	//	associate.toString();
	//	Associate associate=new
	}

}
